MonoPingPong
============

A simple Pong game coded with [MonoGame] (http://www.monogame.net/).

- Single player only
- Basic CPU AI
- Sound effects & Music
- Tested binary on Windows 8

The intent was to get some hands on MonoGame, writing a minimalist game in c# to learn a bit about the XNA pipeline and how Monogame makes multi platform game developement easy to achieve.

![alt tag](http://i58.tinypic.com/2iw13pk.png)
