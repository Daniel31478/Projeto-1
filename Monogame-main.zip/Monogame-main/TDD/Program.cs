﻿
using var game = new TDD.Game1();
game.Run();
